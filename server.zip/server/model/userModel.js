const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const User = sequelize.define('User', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    name: {
        type: DataTypes.STRING(50),
        allowNull: false,
        validate: {
            len: [3, 50]
        }
    },
    email: {
        type: DataTypes.STRING(50),
        allowNull: false,
        unique: true,
        validate: {
            isEmail: true
        }
    },
    password: {
        type: DataTypes.STRING(100),
        allowNull: false
    },
    isAvatarImageSet: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
    avatarImage: {
        type: DataTypes.STRING(255),
        defaultValue: ""
    }
}, {
    tableName: 'users',
    timestamps: true
});

module.exports = User;