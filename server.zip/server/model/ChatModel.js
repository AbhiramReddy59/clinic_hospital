const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const Chat = sequelize.define('Chat', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    members: {
        type: DataTypes.JSON,
        allowNull: false
    }
}, {
    tableName: 'chats',
    timestamps: true
});

module.exports = Chat;