const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');
const Chat = require('./ChatModel');

const Message = sequelize.define('Message', {
    chatId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: Chat,
            key: 'id'
        }
    },
    senderId: {
        type: DataTypes.STRING,
        allowNull: false
    },
    text: {
        type: DataTypes.TEXT,
        allowNull: false
    }
}, {
    timestamps: true
});

module.exports = Message;