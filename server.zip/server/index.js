const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const { sequelize, initializeDatabase } = require('./config/database');
const User = require('./model/userModel');
const Appointment = require('./model/appointmentCheck');

require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// Initialize database
initializeDatabase().catch(err => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});

app.get('/', (req, res) => {
  res.json({ message: 'Hello from server!' });
});

// Appointment booking
app.post('/dental-clinic/slot/', async (req, res) => {
  try {
    const { date, time, name, email, phone } = req.body;

    if (!date || !time || !name || !email || !phone) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    // Check if the slot is already booked
    const existingSlot = await Appointment.findOne({
      where: { date, time }
    });

    if (existingSlot) {
      return res.status(409).json({ message: 'This slot is already booked' });
    }

    // Create the new appointment
    const savedAppointment = await Appointment.create({
      date,
      name,
      email,
      phone,
      time
    });

    return res.status(201).json({
      message: 'Successfully made an appointment',
      appointment: savedAppointment
    });
  } catch (err) {
    console.error('Appointment booking error:', err);
    if (err.name === 'SequelizeValidationError') {
      return res.status(400).json({ message: err.errors[0].message });
    }
    return res.status(500).json({ message: 'Error processing appointment request' });
  }
});

// User registration
app.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ message: 'All fields are required' });
    }

    const userExist = await User.findOne({
      where: { email }
    });

    if (userExist) {
      return res.status(409).json({ message: 'Email already exists' });
    }

    const saltRounds = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, saltRounds);

    const user = await User.create({
      name,
      email,
      password: hashedPassword
    });

    return res.status(201).json({
      message: 'User registered successfully',
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      }
    });
  } catch (err) {
    console.error('Registration error:', err);
    if (err.name === 'SequelizeValidationError') {
      return res.status(400).json({ message: err.errors[0].message });
    }
    return res.status(500).json({ message: 'Error registering user' });
  }
});

// User login
app.post('/login_user', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }

    const user = await User.findOne({
      where: { email }
    });

    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);

    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    return res.status(200).json({
      status: true,
      message: 'Login successful',
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ message: 'Error during login' });
  }
});

// Get user appointments
app.get('/dental-clinic/user/profile', async (req, res) => {
  try {
    const appointments = await Appointment.findAll({
      order: [['date', 'ASC'], ['time', 'ASC']]
    });
    res.json(appointments);
  } catch (err) {
    console.error('Error fetching appointments:', err);
    res.status(500).json({ message: 'Error fetching appointments' });
  }
});

app.get('/dental-clinic/admin-person', async (req, res) => {});

const PORT = process.env.PORT || 5000;

// Start server with error handling
const server = app.listen(PORT, () => {
  console.log(`Server started on port ${PORT}`);
}).on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is already in use. Please try a different port or close the application using this port.`);
  } else {
    console.error('Failed to start server:', err);
  }
  process.exit(1);
});
